using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace Enemys
{
  class Enemy
   {
    public int damag;
    public float SlainExpItem { get; set; } 
    public int SlainExp { get; set; }
    public int healthss { get; set; } 
   public int GoldLoot { get; set; }
   
   public void EnemyHealth(int damage)
   	{
   		this.healthss -= damage;
   	}
  }
}