using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace Potions
{

    public class Potion 
    {
           
    }
}