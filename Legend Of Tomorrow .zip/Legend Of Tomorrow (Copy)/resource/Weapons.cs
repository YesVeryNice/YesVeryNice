using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace Weapons
{
   	public abstract class Item
	{
	   public abstract void Equip();
	   public abstract void Sell();
	   public abstract void UnEquip();
	   public abstract void Info();
	}
     public class Sword : Item
   	{
   	 public string name { get; set; }
   	 public int dmge { get; set;}
   	 public int ItemID { get; set; }
   	 public int goldValue { get; set; }
   	 public float Exp { get; set; }
   	 public int Level = 0;
     
     public Sword(string name)
     {
         this.name = name;
     }
     public void LevelUp()
     {
         Console.WriteLine(name + " Has Level Up!");
     }
     public override void Equip()
     {
         Console.WriteLine("You Have Equipped The " + name);
     }
     public override void UnEquip()
     {
        Console.WriteLine("You Have UnEquip " + name); 
     }
     public override void Info()
     {
         Console.WriteLine("Item Id : " + ItemID);
         Console.WriteLine("Sword's Damage : " + dmge);
         Console.WriteLine("Sword's Level : " + Level);
         Console.WriteLine("Sword's Exp : " + Exp);
     }
     public override void Sell()
     {
        Console.WriteLine("You Have Sold " + name + " For " + goldValue);  
     }
	}
  
    class Axe : Item
    {
      public string name;
   	  public int dmge { get; set;}
   	  public int ItemID { get; set; }
   	  public int goldValue { get; set; }
   	  public float Exp { get; set; }
   	  public int Level {  get; set; }
   	 
   	 public Axe (string name)
   	 {
   	     this.name = name;
   	 }
   	 
      public override void Equip()
      {
          
      }
	  public override void Sell()
	  {
	      
	  }
	  public override void UnEquip()
	  {
	      
	  }
	  public override void Info()
	  {
	      
	  }
    }      
 
}