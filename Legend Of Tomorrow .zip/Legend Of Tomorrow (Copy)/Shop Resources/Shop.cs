using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace Shops
{
   interface IShopMenu
    {
    } 

 public class Shop : IShopMenu
   {
      public int Potions { get; set; }
      public int PotionsGoldValue { get; set; }
      
      void Shops()
      {
         Console.WriteLine("Welcome to Berry's Shop! Type The Letter To Buy!");
         Console.WriteLine("=======================");
         Console.WriteLine("| (P)otions    (G)ears|");
         Console.WriteLine("| (W)eapons    (F)ood |");
         Console.WriteLine("=======================");
        
      }
   }
  class Potions
  {
      
  }
  class HealthPotion : Potions
  {
      
  }
  class DefensePotion
  {
      
  }
}