using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
using Potions;
using Weapons;
using Players;
using Shops;
using Enemys;


namespace project
{

 class Gather
  {
      public int Gold = 5;
      public int Iron = 2;
      
     public void gather1()
     {
        Console.WriteLine("You Have Mined "+ Gold +"  Gold");
     }
      public int Meat = 3;
      public int Feathers = 2;
      
      public void gather2()
      {
          Console.WriteLine("You Have Hunt A Boar And Got "+ Meat +" Meat");
      }
  }
 public class Program 
    {
        public static void Main(string[] args)
        {       //Players Info 
			   Player player = new Player();
			   player.health = 100;
			   player.skills = 3;
			   player.experience = 1.0f;

			   // Sword
			   Sword sword = new Sword("Sword");
			   sword.goldValue = 35;
			   sword.ItemID = 1;
			   sword.Exp = 2.9f;
			   sword.dmge = 24;
			   
			   Sword sword2 = new Sword("Uncommon Sword");
			   sword2.dmge = 39;
			   sword2.ItemID = 2;
			   
			   // Axe
			   Axe axe = new Axe("Axe");
			   axe.goldValue = 37;
			   axe.ItemID = 2;
			   axe.Exp = 0.1f;
			   axe.dmge = 34;
			   
			   List<Item> inventoryss = new List<Item>();
			   Gather gather = new Gather();
			   Enemy enemy = new Enemy();
	
			  // Idk This 
			   string password;
			   password = "$ info";
			   enemy.healthss = 100;
			   enemy.SlainExpItem = 98.5f;
			   string pin;
			   enemy.damag = 23; 
			   pin = "$ attack";
			   string pwds;
			   pwds = "$ inv";
			   string name;
			   string pwd;
			   string equips;
			   equips = "$ equip Excalibuf";
			   pwd = "$ remove Excalibuf";
			   string entry;
			   string mine;
			   mine = "$ mine";
			   string hunt;
			   string chest;
			   hunt = "$ hunt";
			   chest = "$ Chest";
			   string[] aya = new string[] {"sword", "axe"};
		  
			   // Shop
			   Shop shops = new Shop();
			   shops.Potions = 5;
			   shops.PotionsGoldValue = 25;
			   Potion potion = new Potion();
			   
			   // Game's Menu
			   
			    Print(@"Welcome To YesBeryNice Game!
			    Play
			    About
			    Quit");
			    entry = Console.ReadLine();
			  switch (entry)
			  {
			      case "Play":
			      Console.Clear();
			    Print("Hello There!");
			    Thread.Sleep(1000);
			    Print("Please Input Your Name: ");
			    name = Console.ReadLine();
			    Thread.Sleep(500);
			    Print("Lets Get Started!");
			    Thread.Sleep(450);
			    Print("Hello " + name + "! Lets Get to The Game Tutorial! Type $ info To See Your Info");
			    password = Console.ReadLine();
			    
			    bool req = true;
			  do
			  { 
			    if (password == "$ info")
			    {
			        Console.WriteLine("> Your Name is "+ name);
			    	player.Person();
			    	Thread.Sleep(400);
			    	Print("Nice! You got a Chest And Opened it, You Got "+ sword.name);
			    	Thread.Sleep(200);
			    	Print("Now Type $ attack So We Can See The Damage Of Your Sword");
			    	Console.Clear();
			    	pin = Console.ReadLine();
			    }
			    else
			    {
			      req = false;
			      Print("> Invalid Command");
			      password = Console.ReadLine();
			    }
		  	  }while (!req);
		  	
		  	bool rqs = true;
		  	bool damaing = false;
		  	bool CloudRider = false;
		  	do
		  	{
		  	 if (pin == "$ attack")
		  	 {
                enemy.healthss -= sword.dmge;
                Console.ForegroundColor = ConsoleColor.Red; 
		  	 	Print("You Attacked the Enemy He has Now " + enemy.healthss + " Health!");
		  	 	Thread.Sleep(600);
                player.health -= enemy.damag;
		  	 	Print("Enemy has Attacked You! You Have "+ player.health + " Health!");
		  	 	Thread.Sleep(450);
		  	 	Console.ForegroundColor = ConsoleColor.White;
		  	 	Print("Your Excalibuf has Earned "+ sword.Exp + " EXP!");
		  	 	Thread.Sleep(350);
		  	 	Print("Now You Know How To Attack Lets Try Slaying a Enemy! Type $ attack again");
		  	 	pwds = Console.ReadLine();
		  	 }
		  	 else
		  	 {
		  	 	Console.WriteLine("> Invalid Command");
		  	 	pin = Console.ReadLine();
		  	 }
		  	}while(!rqs);
		  
		  
		 
		    CloudRider = true; 
		   damaing = true;
		  if (pin == "$ attack")
		  {
		    enemy.healthss -= sword.dmge;
		    Print("You Have Attacked The Enemy! He Has Now " +enemy.healthss +" Health");
		    while (enemy.healthss > 0)
		     {
		       player.health -= enemy.damag;
		       Print("You Have Attacked The Enemy He Has Now " +enemy.healthss+ " Health");
		       Thread.Sleep(450);
		       Print("Type $ attack Again");
		       enemy.healthss -= sword.dmge;
		       pin = Console.ReadLine();
		       if (enemy.healthss < 1)
		        {
		          Print("You Slayed The Enemy!");
		          Thread.Sleep(500);
		          Print("Type $ inv To See Your Inventory");
		           pwds = Console.ReadLine();
		           if (enemy.healthss < 1)
		           {
		              enemy.SlainExpItem += sword.Exp;
		              if (sword.Exp > 100)
		               {
		                  sword.LevelUp();
		               }
		           }
		        }
		     }
		   }
		  do
		  {
		  	if (pwds == "$ inv")
		  	{
		      inventoryss.Add(sword);
		      
		      foreach (Item items in inventoryss)
		      {
		          Console.WriteLine(sword.name);
		      }
		  	}
		  	else
		  	{
		  		Print("> Invalid Command");
		  		pwds = Console.ReadLine();
		  	}
		  }while(!CloudRider);
		  
		  	Print("Now To Remove A Item In Your Inventory Type $ remove Excalibuf");
		  	pwd = Console.ReadLine();
		  	bool gay = true;
		  do
		  {	
		  	if (pwd == "$ remove Excalibuf")
		  	{
		  	    Console.Clear();
		  	    Print("You Have Removed Excalibuf On Your Inventory");
		  	    Thread.Sleep(560);
		  	    Print("Now Equip The Sword By Typing $ equip Excalibuf");
		  	    inventoryss.Remove(sword);
		  	    if (equips == "$ equip Excalibuf")
		  	    {
		  	       sword.Equip(); 
		  	       Thread.Sleep(450);
		  	       Print("Now Type $ mine to mine gold");
		  	       mine = Console.ReadLine();
		  	    }
		  	}
		  }while(!gay);
		  gay = false;
		  if (mine == "$ mine")
		  {
		    gather.gather1();
		    hunt = Console.ReadLine();
		    Thread.Sleep(450);
		    Print("Now Do $ hunt Ya Wench");
		      if (hunt == "$ hunt")
		       {
		          gather.gather2();
		          chest = Console.ReadLine();
		          if (chest == "$ Chest")
		          {
                      Random rands = new Random();
		              int rands3 = rands.Next(aya.Length);
		              
		              Console.WriteLine($"Name: {aya[1]}");
                  }
		       }
		  }
		       
		  break;
		  
		 case "About":
		 Print("This Game is A RPG, A Project Made By YesBeryNice");
		 Print("This Game is Called Legend Of Tomorrow");
		 entry = Console.ReadLine();
		 break;
		 
		 case "Quit":
		 break;
        }  
    }
      public static void Print(string Text, int speed = 19)
      {
          foreach (char c in Text)
          {
              Console.Write(c);
              System.Threading.Thread.Sleep(speed);
          }
          Console.WriteLine();
      }
   }
}
  