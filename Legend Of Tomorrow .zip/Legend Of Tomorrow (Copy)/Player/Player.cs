using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace Players
{
  class Player
   {
    public string name { get; set; }
    public int health;
    public int skills = 2;
    public float experience { get; set; }
    public int healths { get; set; }
   
   	public void Person()
   	{
   		Console.WriteLine("> Your Health is "+ health);
   		Console.WriteLine("> Your Skills is " + skills);
   		Console.WriteLine("> Your Experience is " + experience);
   	}
   }
}